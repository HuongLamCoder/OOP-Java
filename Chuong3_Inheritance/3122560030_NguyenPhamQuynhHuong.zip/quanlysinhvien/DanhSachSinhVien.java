package quanlysinhvien;

import java.util.Arrays;
import java.util.Scanner;

public class DanhSachSinhVien {
    Scanner sc = new Scanner(System.in);
    private int siSo;
    SinhVien[] arrsv;

    //Constructor
    public DanhSachSinhVien() {
        siSo = 0;
        arrsv = null;
    }

    //Nhập danh sách sinh viên
    public void nhapDSSV() {
        System.out.print("Nhập vào số lượng sinh viên: ");
        siSo = Integer.parseInt(sc.nextLine());
        arrsv = new SinhVien[siSo];

        for (int i = 0; i < siSo; i++) {
            System.out.println("Nhập vào sinh viên thứ #" + (i+1) + "/" + siSo + ":");
            arrsv[i] = new SinhVien();
            arrsv[i].nhap();
        }
    }

    //Xuất danh sách sinh viên
    public void xuatDSSV() {
        System.out.println("Danh sách sinh viên: ");
        System.out.printf("|%-10s|%-25s|%-4s|%-30s|%-10s|%-15s|\n",
                "Mã SV", "Họ và tên SV", "NS", "Địa chỉ", "Số ĐT", "Nơi học");
        for (SinhVien sv : arrsv) {
            sv.xuat();
        }
    }

    //Thay đổi nơi học
    public void thayDoiNoiHoc(String noiHoc) {
        System.out.print("Nhập vào nơi học mới: ");
        noiHoc = sc.nextLine();
    }

    //Tìm kiếm sinh viên bằng masv
        //Cách 1
    public void timKiemSV_1(){
        System.out.print("Nhập mã sinh viên cần tìm: ");
        String masv = sc.nextLine();
        for (SinhVien sv : arrsv) {
            if (sv.getMasv().equalsIgnoreCase(masv)) {
                sv.xuat();
            }
        }
    }
        //Cách 2
    public SinhVien timKiemSV_2() {
        SinhVien sinhVien = null;
        System.out.print("Nhập mã sinh viên cần tìm: ");
        String masv = sc.nextLine();
        for (SinhVien sv : arrsv) {
            if (sv.getMasv().equalsIgnoreCase(masv)){
                sinhVien = sv;
                break;
            }
        }
        return sinhVien;
    }
        //Cách 3
    public SinhVien[] timKiemSV_3() {
        int j = 0;
        SinhVien[] arrSearch = new SinhVien[siSo];
        System.out.print("Nhập mã số sv cần tìm: ");
        String masv = sc.nextLine();
        for(int i = 0; i < arrsv.length; i++){
            if(arrsv[i].getMasv().equalsIgnoreCase(masv)){
                arrSearch[j] = arrsv[i];
                j++;
            }
        }
        return arrSearch;
    }

    //Thêm 1 sinh viên vào danh sách
    public void themSinhVien() {
        System.out.println("NHẬP THÔNG TIN SINH VIÊN CẦN THÊM:");
        SinhVien sv = new SinhVien();
        sv.nhap();

        arrsv = Arrays.copyOf(arrsv, arrsv.length + 1);
        arrsv[siSo] = sv;
        siSo++;
    }

    //Xóa sinh viên khỏi danh sách
    public void xoaSinhVien() {
        System.out.print("Nhập mã sinh viên cần xóa: ");
        String masvCanXoa = sc.nextLine();

        int viTriXoa = -1;  //không tìm thấy sinh viên

        //Tìm vị trí của sinh viên cần xóa trong mảng
        for(int i = 0; i < arrsv.length; i++){
            if(arrsv[i].getMasv().equalsIgnoreCase(masvCanXoa)){
                viTriXoa = i;
                break;  //Tìm được vị trí sinh viên cần xóa và thoát khỏi vòng lặp
            }
        }

        //Xóa sv khỏi danh sách
        if(viTriXoa != -1){
            SinhVien[] newArr = new SinhVien[siSo - 1]; //tạo mảng SinhVien để lưu trữ tạm dssv sau khi xóa
            for(int i = 0, j = 0; i < siSo; i++) {
                if(i != viTriXoa) {     //sao chép những sinh viên không cần xóa qua mảng tạm
                    newArr[j] = arrsv[i];
                    j++;
                }
            }
            arrsv = newArr; //sao chép lại sinh viên từ mảng tạm về mảng SinhVien ban đầu
            siSo--; //giảm số lượng sinh viên
            System.out.println("Sinh viên có mã " + masvCanXoa + " đã được xóa khỏi danh sách!");
        }
        else{
            System.out.println("Không tìm thấy sinh viên cần xóa trong mảng!");
        }
    }
}
