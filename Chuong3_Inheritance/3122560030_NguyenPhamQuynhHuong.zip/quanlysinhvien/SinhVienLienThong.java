package quanlysinhvien;

import java.util.Scanner;

public class SinhVienLienThong extends SinhVien{
    Scanner sc = new Scanner(System.in);
    private String trinhDo;
    private String bangTotNghiep;

    //Constructor
    public SinhVienLienThong() {
        super();
        trinhDo = null;
        bangTotNghiep = null;
    }

    public SinhVienLienThong(String hoTen, int namSinh, DiaChi dc, String sdt, String masv, String noiHoc, String trinhDo, String bangTotNghiep) {
        super(hoTen, namSinh, dc, sdt, masv, noiHoc);
        this.trinhDo = trinhDo;
        this.bangTotNghiep = bangTotNghiep;
    }

    //Getter - Setter
    public String getTrinhDo() {
        return trinhDo;
    }

    public void setTrinhDo(String trinhDo) {
        this.trinhDo = trinhDo;
    }

    public String getBangTotNghiep() {
        return bangTotNghiep;
    }

    public void setBangTotNghiep(String bangTotNghiep) {
        this.bangTotNghiep = bangTotNghiep;
    }

    //Nhập thông tin sinh viên liên thông
    @Override
    public void nhap() {
        super.nhap();
        System.out.print("Nhập trình độ: ");
        trinhDo = sc.nextLine();
        System.out.print("Nhập loại bằng tốt nghiệp: ");
        bangTotNghiep = sc.nextLine();
    }

    //Xuất thông tin sinh viên liên thông
    @Override
    public void xuat() {
        System.out.printf("|%-10s|%-25s|%-4d|%-30s|%-10s|%-15s|%-10s|%-10s|\n",
                masv, hoTen, namSinh, dc, sdt, noiHoc, trinhDo, bangTotNghiep);
    }
}
