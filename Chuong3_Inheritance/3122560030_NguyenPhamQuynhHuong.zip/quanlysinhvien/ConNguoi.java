package quanlysinhvien;

import java.util.Scanner;

public class ConNguoi {
    Scanner sc = new Scanner(System.in);
    protected String hoTen;
    protected int namSinh;
    protected DiaChi dc;
    protected String sdt;

    //Constructor
    public ConNguoi(String hoTen, int namSinh, DiaChi dc, String sdt) {
        this.hoTen = hoTen;
        this.namSinh = namSinh;
        this.dc = dc;
        this.sdt = sdt;
    }

    public ConNguoi() {
        hoTen = null;
        namSinh = 0;
        dc = new DiaChi();
        sdt = null;
    }

    //Getter - Setter
    public String getHoTen() {
        return hoTen;
    }

    public void setHoTen(String hoTen) {
        this.hoTen = hoTen;
    }

    public int getNamSinh() {
        return namSinh;
    }

    public void setNamSinh(int namSinh) {
        this.namSinh = namSinh;
    }

    public DiaChi getDc() {
        return dc;
    }

    public void setDc(DiaChi dc) {
        this.dc = dc;
    }

    public String getSdt() {
        return sdt;
    }

    public void setSdt(String sdt) {
        this.sdt = sdt;
    }

    //Nhập thông tin
    public void nhap() {
        System.out.print("Nhập họ và tên: ");
        this.hoTen = sc.nextLine();
        System.out.print("Nhập năm sinh: ");
        this.namSinh = Integer.parseInt(sc.nextLine());
        System.out.println("Nhập địa chỉ: ");
        dc.nhapDC();
        System.out.print("Nhập số điện thoại: ");
        this.sdt = sc.nextLine();
    }

    public void xuat() {

    }
}