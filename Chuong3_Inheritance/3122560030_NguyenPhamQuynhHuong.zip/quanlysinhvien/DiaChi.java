package quanlysinhvien;

import java.util.Scanner;

public class DiaChi {
    Scanner sc = new Scanner(System.in);
    private String soNha;
    private String duong;
    private String quan;
    private String tp;

    //Constructor
    public DiaChi(String soNha, String duong, String quan, String tp) {
        this.soNha = soNha;
        this.duong = duong;
        this.quan = quan;
        this.tp = tp;
    }

    public DiaChi() {
        soNha = null;
        duong = null;
        quan = null;
        tp = null;
    }

    //Getter - Setter

    public String getSoNha() {
        return soNha;
    }

    public void setSoNha(String soNha) {
        this.soNha = soNha;
    }

    public String getDuong() {
        return duong;
    }

    public void setDuong(String duong) {
        this.duong = duong;
    }

    public String getQuan() {
        return quan;
    }

    public void setQuan(String quan) {
        this.quan = quan;
    }

    public String getTp() {
        return tp;
    }

    public void setTp(String tp) {
        this.tp = tp;
    }

    //Nhập địa chỉ
    public void nhapDC() {
        System.out.print("Nhập số nhà: ");
        this.soNha = sc.nextLine();
        System.out.print("Nhập tên đường: ");
        this.duong = sc.nextLine();
        System.out.print("Nhập quận: ");
        this.quan = sc.nextLine();
        System.out.print("Nhập thành phố: ");
        this.tp = sc.nextLine();
    }

    //toString()
    @Override
    public String toString() {
        return this.soNha + " " + this.duong + ", Quận " + this.quan + ", Tp." + this.tp;
    }
}
