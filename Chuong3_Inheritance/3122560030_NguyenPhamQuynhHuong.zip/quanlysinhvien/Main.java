package quanlysinhvien;

public class Main {
    public static void main(String[] args) {
        SinhVienLienThong svlt = new SinhVienLienThong();
        svlt.nhap();
        svlt.xuat();
    }
}