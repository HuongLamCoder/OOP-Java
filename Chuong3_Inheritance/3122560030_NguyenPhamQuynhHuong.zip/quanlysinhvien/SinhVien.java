package quanlysinhvien;

import java.util.Scanner;

public class SinhVien extends ConNguoi {
    Scanner sc = new Scanner(System.in);
    protected String masv;
    protected String noiHoc;

    //Constructor
    public SinhVien() {
        super();
        masv = null;
        noiHoc = null;
    }

    public SinhVien(String hoTen, int namSinh, DiaChi dc, String sdt, String masv, String noiHoc) {
        super(hoTen, namSinh, dc, sdt);
        this.masv = masv;
        this.noiHoc = noiHoc;
    }

    //Getter - Setter
    public String getMasv() {
        return masv;
    }

    public void setMasv(String masv) {
        this.masv = masv;
    }

    public String getNoiHoc() {
        return noiHoc;
    }

    public void setNoiHoc(String noiHoc) {
        this.noiHoc = noiHoc;
    }

    //Nhập sinh viên
    @Override
    public void nhap() {
        System.out.print("Nhập mã sinh viên: ");
        this.masv = sc.nextLine();
        super.nhap();   //nhập các thông tin họ tên, năm sinh, địa chỉ, sđt
        System.out.print("Nhập nơi học: ");
        this.noiHoc = sc.nextLine();
    }

    //Xuất thông tin sinh viên
    @Override
    public void xuat() {
        System.out.printf("|%-10s|%-25s|%-4d|%-30s|%-10s|%-15s|\n",
                          masv, hoTen, namSinh, dc, sdt, noiHoc);
    }

    @Override
    public String toString() {
        return "Mã SV: " + masv + "\nHọ tên: " + hoTen + "\nNăm sinh: " + namSinh + "\nĐịa chỉ: " + dc + "\nSĐT: " + sdt + "\nNơi học: " + noiHoc;
    }
}
